grails.project.dependency.resolution = {

   inherits 'global'
   log 'warn'

   repositories {
      mavenCentral()
   }

   dependencies {
       provided('org.codenarc:CodeNarc:0.14') {
           transitive = false
       }
       provided('org.gmetrics:GMetrics:0.3') {
           transitive = false
       }
   }
}
